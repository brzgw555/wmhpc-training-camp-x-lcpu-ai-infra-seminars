
#include "common.h"

int main()
{
    cudaDeviceProp prop;
    CUDA_CHECK(cudaGetDeviceProperties(&prop, 0));

    printf("GPU             : %s\n", prop.name);                     // NVIDIA RTX PRO 6000 Blackwell Server Edition
    printf("compute capability  : %d.%d\n", prop.major, prop.minor); // 12.0

    // ======  1 ======
    printf("SM              : %d\n", /* todo */ prop.multiProcessorCount); // 188

    // ====== 2 size ======
    printf("warp size           : %d\n", /* todo */ prop.warpSize); // 32

    // ====== 3 per block  shared memory======
    printf("shared mem / block  : %zu\n", (size_t)/* todo */ prop.sharedMemPerBlock); // 49152

    // ======  4: ======
    printf("max threads / SM    : %d\n", /* todo */ prop.maxThreadsPerMultiProcessor); // 1536

    // ====== 5 ======
    printf("global mem          : %zu\n", (size_t)/* todo */ prop.totalGlobalMem); // 101975851008

    printf("max threads / block : %d\n", prop.maxThreadsPerBlock); // 1024
    return 0;
}
